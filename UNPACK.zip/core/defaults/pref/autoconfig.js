// First line must be a comment
pref("general.config.filename", "mozilla.cfg");
pref("general.config.obscure_value", 0);
pref("general.config.sandbox_enabled", false);
pref("general.config.delay_load", false);  // Load configuration immediately
pref("privacy.resistFingerprinting", true);  // Enable fingerprinting resistance by default
