// Disable all types of telemetry
lockPref("toolkit.telemetry.enabled", false);
lockPref("toolkit.telemetry.unified", false);
lockPref("toolkit.telemetry.server", "");
lockPref("toolkit.telemetry.archive.enabled", false);
lockPref("toolkit.telemetry.newProfilePing.enabled", false);
lockPref("toolkit.telemetry.shutdownPingSender.enabled", false);
lockPref("toolkit.telemetry.updatePing.enabled", false);
lockPref("toolkit.telemetry.bhrPing.enabled", false);
lockPref("toolkit.telemetry.firstShutdownPing.enabled", false);
lockPref("toolkit.telemetry.coverage.opt-out", true);
lockPref("toolkit.coverage.opt-out", true);
lockPref("toolkit.coverage.endpoint.base", "");
lockPref("browser.ping-centre.telemetry", false);

// Disable health reports
lockPref("datareporting.healthreport.uploadEnabled", false);
lockPref("datareporting.healthreport.service.enabled", false);
lockPref("datareporting.policy.dataSubmissionEnabled", false);

// Disable crash reports
lockPref("browser.crashReports.unsubmittedCheck.autoSubmit2", false);
lockPref("browser.crashReports.unsubmittedCheck.enabled", false);
lockPref("browser.tabs.crashReporting.sendReport", false);
lockPref("browser.crashReports.unsubmittedCheck.autoSubmit", false);

// Disable updates
lockPref("app.update.enabled", false);
lockPref("app.update.auto", false);
lockPref("app.update.mode", 0);
lockPref("app.update.service.enabled", false);
lockPref("app.update.url", "");
lockPref("app.update.url.manual", "");
lockPref("app.update.url.details", "");

// Disable studies and experiments
lockPref("app.shield.optoutstudies.enabled", false);
lockPref("messaging-system.rsexperimentloader.enabled", false);
lockPref("browser.discovery.enabled", false);
lockPref("browser.newtabpage.activity-stream.feeds.telemetry", false);
lockPref("browser.newtabpage.activity-stream.telemetry", false);

// Disable other data collection
lockPref("beacon.enabled", false);
lockPref("browser.send_pings", false);
lockPref("browser.urlbar.eventTelemetry.enabled", false);
lockPref("browser.newtabpage.activity-stream.feeds.section.topstories", false);
lockPref("browser.newtabpage.activity-stream.section.highlights.includePocket", false);
lockPref("browser.newtabpage.activity-stream.showSponsored", false);
lockPref("browser.newtabpage.activity-stream.feeds.discoverystreamfeed", false);
lockPref("browser.newtabpage.activity-stream.showSponsoredTopSites", false);
lockPref("network.allow-experiments", false);
lockPref("privacy.trackingprotection.enabled", true);
lockPref("privacy.trackingprotection.socialtracking.enabled", true);
lockPref("privacy.trackingprotection.cryptomining.enabled", true);
lockPref("privacy.trackingprotection.fingerprinting.enabled", true);

// Disable Normandy/Shield
lockPref("app.normandy.enabled", false);
lockPref("app.normandy.api_url", "");

// Disable WebRTC telemetry
lockPref("media.webrtc.analytics.enabled", false);

// Disable Firefox Accounts and Sync telemetry
lockPref("identity.fxaccounts.enabled", false);
lockPref("services.sync.telemetry.enabled", false);

// Disable Captive Portal detection
lockPref("network.captive-portal-service.enabled", false);

// Disable Network connectivity checks
lockPref("network.connectivity-service.enabled", false);

// Disable Background App Update
lockPref("app.update.background.scheduling.enabled", false);

// Disable Extension Recommendations
lockPref("extensions.getAddons.showPane", false);
lockPref("extensions.htmlaboutaddons.recommendations.enabled", false);

// Disable Pocket
lockPref("extensions.pocket.enabled", false);

// Enhanced Tracking Protection
lockPref("privacy.trackingprotection.enabled", true);
lockPref("privacy.trackingprotection.pbmode.enabled", true);
lockPref("privacy.trackingprotection.cryptomining.enabled", true);
lockPref("privacy.trackingprotection.fingerprinting.enabled", true);

// Disable prefetching
lockPref("network.dns.disablePrefetch", true);
lockPref("network.dns.disablePrefetchFromHTTPS", true);
lockPref("network.predictor.enabled", false);
lockPref("network.predictor.enable-prefetch", false);
lockPref("network.prefetch-next", false);
lockPref("network.http.speculative-parallel-limit", 0);
